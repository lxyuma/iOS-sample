//
//  AppDelegate.h
//  HTTPSample
//
//  Created by zabaglione on 2013/09/14.
//  Copyright (c) 2013年 zabaglione. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
